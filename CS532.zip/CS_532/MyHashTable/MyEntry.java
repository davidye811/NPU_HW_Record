package MyHashTable;

public class MyEntry<E,V> {
	E e;
	V v;
	MyEntry<E,V> next=null;
	public MyEntry(){
		
	}
	public MyEntry(E e,V v){
		this.e=e;
		this.v=v;
	}
}
