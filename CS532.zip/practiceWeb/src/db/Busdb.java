package db;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import exceptions.AccountDbFailure;
import npuBus.domain.Bus;

/* Methods to perform operations on the bank database */
public class Busdb {
	private static int maxTimesToRetry = 3;

	public static Bus getBusWithBusid(String busid) throws  AccountDbFailure,SQLException {
		Bus curBus;
		Connection dbConn;
    	Connection dbConn2;
    	  dbConn = BusAppDataSource.getConnection();
          dbConn2 = BusAppDataSource.getConnection();
          dbConn.setAutoCommit(false);
          dbConn2.setAutoCommit(false);
          curBus=getBusWithDbConnection(dbConn,busid);
		return curBus;
	}

	private static Bus getBusWithDbConnection(Connection dbConn, String busid)  throws  AccountDbFailure,SQLException{
		String readCurBusSql="select * from busdb.bus b where b.busid=?";
		Bus curBus=new Bus();
		try(PreparedStatement readCurBusStmt =dbConn.prepareStatement(readCurBusSql)){
			readCurBusStmt.setString(1, busid);
			curBus=getBusWithSqlStmt(readCurBusStmt);
		}
		return curBus;
	}

	private static Bus getBusWithSqlStmt(PreparedStatement readCurBusStmt) throws SQLException {
		Bus curBus =new Bus();
		try(ResultSet results =readCurBusStmt.executeQuery();){
			if(results.next()){
				curBus.setBusId(results.getString("busid"));
				curBus.setCapability(results.getInt("capability"));
				curBus.setDrivername(results.getString("drivername"));
				curBus.setPhone(results.getString("phone"));
			}
		}
		return curBus;
	}
	
}
