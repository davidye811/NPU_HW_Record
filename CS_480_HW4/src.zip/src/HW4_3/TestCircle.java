package HW4_3;

public class TestCircle {
	public static void main(String[] argv){
		Circle c1 = new Circle(5.0);
		System.out.println(c1.toString());
	}
}
