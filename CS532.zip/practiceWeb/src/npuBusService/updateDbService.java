package npuBusService;

import java.sql.SQLException;

import db.Busdb;
import exceptions.AccountDbFailure;
import npuBus.domain.Bus;

public class updateDbService {
	public static Bus getBus(String busid) {
		double initialBal, finalBal;
		
		try {
			return Busdb.getBusWithBusid(busid);
		} catch (AccountDbFailure ex) {
			System.out.println("Failure with Database operation: "
					+ ex.getReasonStr());
		} catch (SQLException ex) {
			System.out.println("Database operation failure: " + ex);
		}finally{
			return null;
		}
	}
}
